#include "LinkedList.h"


template <class T>
LinkedList<T>::LinkedList()
{
    first = NULL;
    last = NULL;
}

template <class T>
LinkedList<T>::~LinkedList()
{
    Node<T>* temp = first;
    while (temp != NULL)
    {
        temp = temp->next;
        delete(first);
        first = temp;
    }
}

template <class T>
void LinkedList<T>::insertAtBack(T valueToInsert)
{
    Node<T>* newNode;
    newNode->val = valueToInsert;
    newNode->next = NULL;

    Node<T>* temp = first;

    if (temp != NULL)
    {
        while (temp->next != NULL)
        {
            temp = temp->next;
        }

        temp->next = newNode;
    }
    else
    {
        first = newNode;
    }
}

template <class T>
bool LinkedList<T>::removeFromBack()
{
    if (first == NULL && last == NULL) { return false; }

    if (first == last)
    {
        //Serial.println("First is equal to Last.");
        delete(first);
        first = last = NULL;
        return true;
    }

    else
    {
        Node<T>* temp = first;
        int nodeCount = 0;

        while (temp != NULL)
        {
            nodeCount = nodeCount + 1;
            temp = temp->next;
        }

        Node<T>* temp2 = first;

        for (int i = 1; i < (nodeCount - 1); i++)
        {
            temp2 = temp2->next;
        }

        //Serial.println(temp2->val);
        delete(temp2->next);

        last = temp2;
        last->next = NULL;

        return true;
    }
}

template <class T>
void LinkedList<T>::print()
{
    Node<T>* temp = first;

    if (temp == NULL)
    {
        //Serial.print("");
    }

    if (temp->next == NULL)
    {
        //Serial.print(temp->val);
    }
    else
    {
        while (temp != NULL)
        {
            //Serial.print(temp->val);
            temp = temp->next;
            //Serial.print(",");
        }
    }
}

template <class T>
bool LinkedList<T>::isEmpty()
{
    if (first == NULL && last == NULL) { return true; }
    else { return false; }
}

template <class T>
int LinkedList<T>::size()
{
    if (first == NULL && last == NULL) { return 0; }

    Node<T>* temp = first;
    int nodeCounter = 0;

    while (temp != NULL)
    {
        nodeCounter = nodeCounter + 1;
        temp = temp->next;
    }
    return nodeCounter;
}

template <class T>
void LinkedList<T>::clear()
{
    Node<T>* temp = first;
    while (temp != NULL)
    {
        temp = temp->next;
        first = temp;
        delete(temp);
    }
}

template <class T>
void LinkedList<T>::insertAtFront(T valueToInsert)
{
    Node<T>* newNode;

    newNode->val = valueToInsert;

    if (first == NULL)
    {
        first = newNode;
    }
    else
    {
        newNode->next = first;
        first = newNode;
    }

}

template <class T>
bool LinkedList<T>::removeFromFront()
{
    if (first == NULL && last == NULL) { return false; }

    else
    {
        Node<T>* temp;

        temp = first;
        first = first->next;

        delete(temp);

        return true;
    }
}

template <class T>
T& LinkedList<T>::firstNum()
{
    return first->val;
}

template <class T>
void LinkedList<T>::enqueue(T value)
{
    insertAtBack(value);
}

template <class T>
T LinkedList<T>::dequeue()
{
    if (isEmpty())
    {
        //Serial.println("Call to dequeue() generated an exception, because the queue is empty.");
    }
    else
    {
        T firstElmnt = firstNum();
        removeFromFront();

        return firstElmnt;
    }
}

template <class T>
T& LinkedList<T>::front()
{
    if (isEmpty())
    {
        //Serial.println("Call to front() generated an exception, because the queue is empty.");
    }
    else
    {
        return firstNum();
    }
}