#include "Gsm.h"

M590::M590()
{
    _gsmSerial = NULL;
    _debugSerial = NULL;
}

bool M590::enableDebugSerial(HardwareSerial *debugSerial) {
    if (debugSerial)
    {
        _debugSerial = debugSerial;
        return true;
    }
    else
    {
        _debugSerial = NULL;
        return false;
    }
}

bool M590::init(unsigned long baudRate, HardwareSerial *gsmSerial, String pin="")
{
    bool retVal = false;

    if (_gsmSerial) 
    {
        _gsmSerial = gsmSerial;
        _gsmSerial->begin(baudRate);

        retVal = true;
    }
    else
    {
        _gsmSerial = NULL;
        retVal =  false;
    }

    return retVal;
}

bool M590::checkAlive(){
    /* Check if the modem is alive */
    CommandType c;
    c.commandID = M590_COMMAND_AT;
    c.parameter = "";
    c.responebuffer = NULL;
    c.responseID = M590_RESPONSE_OK;
    c.commandCbk = NULL;
    _commandFifo.add(c);
}

void M590::process()
{
    if (_gsmState == MODEM_IDLE)
    {/* Check for new job */

        if (_commandFifo.getItemCount())
        {/* There is job in the fifo, process it */
            CommandType c;

            _commandFifo.remove(&c);

            sendCommand(c.commandID,c.parameter);
            readForResponse(c.responseID,1000);
        }
        else
        {/* There is no job in the fifo, idle task can run */

        }

    }
    else
    {/* Process ongoing job*/

    }

    /*Cyclic call of the assigned handler */
    (this->*_handlerCbk)();
}

void M590::resetAsyncVariables() {
    _asyncStartTime = 0;
    _asyncBytesMatched = 0;
    _asyncResponseLength = 0;
    _asyncProgmemResponseString = NULL;
    _asyncResponseIndex = 0;
}

void M590::sendCommand(const char *progmemCommand, const char *params) {
    _gsmSerial->print((__FlashStringHelper *)progmemCommand);

    if (params && strlen(params))
    {
        _gsmSerial->print(params);;
    }
    _gsmSerial->println(); //terminate with CLRF
}

/* Initialize the asynchronous response reading */
void M590::readForResponse(const char *progmemResponseString, const unsigned int timeout)
{
    /* Start the timeout timer for async reading */
    _asyncStartTime = millis();
    /* save responseString pointer to look for in private variable (for responsehandler) */
    _asyncProgmemResponseString = progmemResponseString;
    _asyncResponseLength = strlen_P(progmemResponseString);

    _asyncTimeout = timeout;

}

/* Cyclic function to read for responses asynchronously */
void M590::responseHandler()
{
    switch (_responseState)
    {
        case GSM_RESPONSE_RUNNING:
            if (millis() > _asyncStartTime + _asyncTimeout)
            {
                resetAsyncVariables();

                /* Action for timeout */
                _responseState = GSM_RESPONSE_TIMEOUT;
                break;
            }

            while (_gsmSerial->available())
            {
                char c = (char)_gsmSerial->read();

                if (c == pgm_read_byte_near(_asyncProgmemResponseString + _asyncBytesMatched)) 
                {
                    _asyncBytesMatched++;

                    if (_asyncBytesMatched == _asyncResponseLength) 
                    {
                        resetAsyncVariables();
                        /* Action for success */
                        _responseState = GSM_RESPONSE_SUCCESS;
                    }
                }
                else
                {
                    _asyncBytesMatched = 0;
                }
            }

        break;

        case GSM_RESPONSE_TIMEOUT:
            if (_commandCbk != NULL)
            {
                _commandCbk(GSM_RESPONSE_TIMEOUT);
                _responseState = GSM_RESPONSE_IDLE;
            }
        break;

        case GSM_RESPONSE_SUCCESS:
            if (_commandCbk != NULL)
            {
                _commandCbk(GSM_RESPONSE_SUCCESS);
                _responseState = GSM_RESPONSE_IDLE;
            }
            break;

        case GSM_RESPONSE_IDLE:
            resetAsyncVariables();
            break;
        default:
            //you should never reach here
            break;
    }
}
