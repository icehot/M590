// M590.h

#ifndef _GSM_h
#define _GSM_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif


typedef struct {
    const char* commandID;
    const char* parameter;
    void(*handlerCbk)() = NULL;
    const char* responseID;
    char* responebuffer;
    void(*commandCbk)(bool success) = NULL;
}CommandType;

typedef enum {
    M590_MODEM_IDLE = 0,
    M590_MODEM_BUSY = 1
}ModemStateType;


typedef enum {
    M590_RESPONSE_IDLE = 0,
    M590_RESPONSE_RUNNING = 1,
    M590_RESPONSE_SUCCESS = 2,
    M590_RESPONSE_TIMEOUT = 3
}ResponseStateType;
const char
M590_COMMAND_AT[]                       PROGMEM = "AT",
M590_RESPONSE_OK[]                      PROGMEM = "OK\r\n";

class M590
{
    public:
        M590();
        bool init(unsigned long baudRate, HardwareSerial *gsmSerial, String pin = "");
        bool enableDebugSerial(HardwareSerial *debugSerial);
        void process();

        bool checkAlive();

    private:
        HardwareSerial *_gsmSerial;
        HardwareSerial *_debugSerial;
        Fifo<CommandType> _commandFifo;
        ModemStateType _gsmState = MODEM_IDLE;
        ResponseStateType _responseState = GSM_RESPONSE_IDLE;

        unsigned long _asyncStartTime = 0;
        unsigned long _asyncTimeout = 0;
        const char *_asyncProgmemResponseString = NULL;
        byte _asyncResponseLength = 0;
        byte _asyncBytesMatched = 0;
        void(*_commandCbk)(ResponseStateType response) = NULL;

        void resetAsyncVariables();
        void sendCommand(const char *progmemCommand, const char *params);
        void readForResponse(const char *progmemResponseString, const unsigned int timeout);
        void responseHandler();
};

#endif

